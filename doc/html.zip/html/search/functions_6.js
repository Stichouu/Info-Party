var searchData=
[
  ['sdl_5fafficheruneimage_48',['SDL_AfficherUneImage',['../petite__fonction_8c.html#ad049bc7aea54b9afd7d083055f877647',1,'petite_fonction.c']]],
  ['sdl_5fexitwitherror_49',['SDL_ExitWithError',['../petite__fonction_8c.html#abed124ab111ee095d48f08e2a3ea4446',1,'petite_fonction.c']]]
];
